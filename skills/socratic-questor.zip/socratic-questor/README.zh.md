# 苏格拉底式对话助手 (Socratic Questor - Gadfly)

**Language / 语言:** [English](./README.md) | [Tiếng Việt](./README.vi.md) | [中文](./README.zh.md)

此 Skill 激活了一个名为 **Gadfly** 的特殊学习伙伴。它通过提问而不是直接给出解释，来帮助您深入理解任何主题。

## Gadfly 是什么？

Gadfly 的名字来源于苏格拉底将自己比作“雅典的牛虻”——那个通过不断叮咬来促使人们思考的人。Gadfly 不会让你被动地阅读或倾听解释，而是通过有结构性的对话，迫使您进行深入思考、调动思维并自己发现真理。

## 为什么使用它？

- **主动学习 (Active Learning)**：当你必须自己寻找答案并用自己的语言表达时，你会记的更牢、理解得更深。
- **深挖本质**：帮助您剥离默认的假设、检验实际论据、从不同的对立角度看问题，并认清论证背后的潜在后果。
- **自动根据水平调整**：Gadfly 会根据您的回答质量自动调整问题的难度。无论您是初学者还是专家，都会获得合适难度的思维挑战。
- **锻炼批判性思维**：帮助您学会进行严密的逻辑论证，以此来捍卫或修正自己的观点，而不是死记硬背事实。
- **聪明而富有挑战**：当您遇到瓶颈时，Gadfly 会将问题拆分为更简单的部分或给出直观示例，但**绝对不会**直接给出答案，以维护“苏格拉底契约”。

## 工作原理

Gadfly 围绕苏格拉底提问框架的 6 个步骤来引导对话：
1. **澄清 (Clarification)**：探索您已知的知识以及您如何定义核心概念。
2. **假设 (Assumptions)**：检验您想法背后的默认预设。
3. **论据 (Evidence)**：要求提供理由、事实或具体例子来巩固论点。
4. **视角 (Perspectives)**：挑战您从相反或替代的角度来看待问题。
5. **影响与后果 (Implications)**：探索从您的回答中得出的逻辑结论或后续影响。
6. **元问题 (Meta-questions)**：回顾整个讨论，自我评估自己的思维发生了怎样的变化。

## 如何触发

让 AI 执行如下任务：

```text
用苏格拉底方法教我相对论。
```

```text
帮助我深入理解股票市场的运作方式。
```

```text
请扮演 Gadfly 并通过提问来检验我对面向对象编程的理解。
```

## 安装

### 1. 使用 CLI（推荐）

```bash
npx skills add tronghieu/agent-skills --skill socratic-questor
```

### 2. 手动安装（适合非技术用户）

1. **下载：** 转到此仓库的 `skills/` 文件夹下载 `socratic-questor.zip` 文件。
2. **解压和复制：** 解压 `socratic-questor.zip` 并将 `socratic-questor` 文件夹复制到以下目录之一：

**针对特定项目：**
将 `socratic-questor` 文件夹复制到项目根目录下的 `.agents/skills/` 或 `.claude/skills/`。

**全局安装（所有项目可用）：**
* **Mac / Linux：** `~/.agents/skills/` 或 `~/.claude/skills/`
* **Windows：** `%USERPROFILE%\.agents\skills\` 或 `%USERPROFILE%\.claude\skills\`（通常为 `C:\Users\<YourUsername>`）
