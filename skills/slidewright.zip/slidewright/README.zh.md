# 网页演示文稿制作助手 (SlideWright)

**Language / 语言:** [English](./README.md) | [Tiếng Việt](./README.vi.md) | [中文](./README.zh.md)

此 Skill 可帮助您快速构建干净、现代且具有交互性的演示文稿（幻灯片），专为向现场观众投影展示而设计。

## SlideWright 是什么？

SlideWright 是一款将演示文稿生成为快速、轻量化网站的工具。您无需在 PowerPoint 或 Keynote 繁琐的界面中挣扎，只需使用 Markdown 或 React 编写幻灯片。SlideWright 会自动建立开箱即用的专业设计系统（Design System），确保您的演示文稿看起来高端，且能让坐在后排的观众轻松看清。

## 为什么使用它？

- **极简设计系统规范**：强制执行现场演讲的关键视觉规则，例如“排版字号底线”（正文文字至少为 40px，以便从远处阅读）和严谨的布局预设。
- **两种灵活的构建路径**：
  - **纯 HTML 模式（无需构建）**：单个 `index.html` 文件，可在任何浏览器中立即可视化运行。最适合制作快速、小巧的幻灯片（20 页以内）。
  - **Vite + React 模式**：初始化一个完整的现代 React 项目，使用 Tailwind CSS 和 Framer Motion 来实现流畅美观的页面转场和自定义动画。
- **专注于演讲者**：幻灯片仅包含视觉线索和最简文字。详细的演讲脚本或备注（speaker notes）将自动生成在独立的 Markdown 文件（`*-notes.md`）中，以便在演讲时进行对照。
- **轻松导出 PDF**：附带脚本工具，可将完整渲染的页面捕获为随时可用于打印或分享的 PDF 文档。

## 幻灯片设计的核心规则

与普通网站不同，演示文稿具有完全不同的视觉目的：
- **只使用大号字体**：绝对不要使用默认的网页阅读字号（如 `16px`、`text-sm`）。
- **没有复杂的应用交互**：没有表单提交、输入框或登录页面。唯一的交互是您点击鼠标来逐步显示下一项要点或进行切换。
- **每页幻灯片只表达一个核心想法**：使观众能够集中精力听您演讲，而不是忙于阅读满屏的文字。

## 如何触发

让 AI 执行如下任务：

```text
帮我为下周的技术分享会制作一套幻灯片。
```

```text
使用 HTML 模式新建一个关于 AI Agent 主题的演示文稿。
```

```text
为 10 分钟的项目路演撰写幻灯片内容和演讲者备注。
```

## 安装

### 1. 使用 CLI（推荐）

```bash
npx skills add tronghieu/agent-skills --skill slidewright
```

### 2. 手动安装（适合非技术用户）

1. **下载：** 转到此仓库的 `skills/` 文件夹下载 `slidewright.zip` 文件。
2. **解压和复制：** 解压 `slidewright.zip` 并将 `slidewright` 文件夹复制到以下目录之一：

**针对特定项目：**
将 `slidewright` 文件夹复制到项目根目录下的 `.agents/skills/` 或 `.claude/skills/`。

**全局安装（所有项目可用）：**
* **Mac / Linux：** `~/.agents/skills/` 或 `~/.claude/skills/`
* **Windows：** `%USERPROFILE%\.agents\skills\` 或 `%USERPROFILE%\.claude\skills\`（通常为 `C:\Users\<YourUsername>`）
