# 虚构文学创作工坊 (Fiction Studio)

**Language / 语言:** [English](./README.md) | [Tiếng Việt](./README.vi.md) | [中文](./README.zh.md)

此 Skill 将您的 AI 助手转化为一个由文学专家组成的虚拟**编剧室**（Writers' room），帮助您构思、大纲设定、撰写初稿、编辑和润色您的故事或小说。

## Fiction Studio 是什么？

Fiction Studio 是一款结构化的创意写作套件。您不再是与普通的聊天机器人交谈，而是与一个由文学大师命名的专业 AI 专家团队合作。在 **Homer**（项目总协调）的带领下，每位专家负责创作的一个特定维度——从与 **Aristotle** 架构剧情、与 **Fyodor** 塑造人物深度、与 **Tolkien** 构建世界，到与 **Oscar** 雕琢对话以及与 **Max** 进行编辑。

## 为什么使用它？

- **专业协同工作**：模拟了真实的编剧室流程，专家们每次只专注于一项任务（例如，在起草前打磨人物心理，在起草后精雕细琢对话）。
- **交互式控制**：遵循 *启发性原则 (Elicitation Rule)*——AI 总是会停下来为您提供带编号的剧情走向选择，而不是在没有您同意的情况下擅自往下写。
- **保持连贯性**：包含一致性检查器和结构化的 `canon.json`，用于在长篇草稿中跟踪人物姓名、时间线、外貌特征以及伏笔与呼应（setup/payoff）。
- **创意圆桌会议 ("Party Mode")**：召集 3-4 位专家的圆桌头脑风暴会议，共同解决情节漏洞、讨论结局或打破写作瓶颈。
- **端到端流程**：引导您从一句简单的原始创意，最终生成完整的初稿手稿和图书提案工具包 (Pitch Kit)。

## 编剧团队介绍

- **Homer**：项目总协调（把握作品愿景、为专家分配工作并管理文件）。
- **Aristotle**：剧情架构师（结构、节奏、大纲）。
- **Fyodor**：角色心理学家（心理创伤、渴望、角色弧线与声音）。
- **Tolkien**：世界构建师（背景设定、规则、文化、魔法/科技系统）。
- **Scheherazade**：叙事编织者（制定场景清单并撰写小说初稿）。
- **Oscar**：对话专家（台词、弦外之音、角色的独特说话方式）。
- **Max**：编辑（结构编辑和行文编辑、制定修改计划）。
- **Virginia**：试读者（扮演客观读者的角色，提供真实的阅读反馈）。
- **Borges**：类型片顾问（确保类型规范和对读者的承诺）。
- **Bloom**：文学评论家（提供高水平的学术文学评论）。

## 如何触发

让 AI 执行如下任务：

```text
我有一个科幻小说的创意，让我们启动 Fiction Studio 创作流程。
```

```text
我这一章的对话听起来有点干瘪。能让 Oscar 帮我看看吗？
```

```text
让我们召开编剧室圆桌会议，为我的推理故事 brainstorm 一个反转结局。
```

## 安装

### 1. 使用 CLI（推荐）

```bash
npx skills add tronghieu/agent-skills --skill fiction-studio
```

### 2. 手动安装（适合非技术用户）

1. **下载：** 转到此仓库的 `skills/` 文件夹下载 `fiction-studio.zip` 文件。
2. **解压和复制：** 解压 `fiction-studio.zip` 并将 `fiction-studio` 文件夹复制到以下目录之一：

**针对特定项目：**
将 `fiction-studio` 文件夹复制到项目根目录下的 `.agents/skills/` 或 `.claude/skills/`。

**全局安装（所有项目可用）：**
* **Mac / Linux：** `~/.agents/skills/` 或 `~/.claude/skills/`
* **Windows：** `%USERPROFILE%\.agents\skills\` 或 `%USERPROFILE%\.claude\skills\`（通常为 `C:\Users\<YourUsername>`）
