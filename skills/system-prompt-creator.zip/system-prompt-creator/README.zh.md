# 系统 Prompt 生成助手 (System Prompt Creator)

**Language / 语言:** [English](./README.md) | [Tiếng Việt](./README.vi.md) | [中文](./README.zh.md)

此 Skill 将引导您通过结构化、专业化的流程，为任何 AI 模型（如 Claude、ChatGPT、Gemini 等）创建高效的系统 Prompt（系统指令）。

## 此 Skill 有何用途？

系统 Prompt 定义了 AI 的行为方式、必须遵守的规则以及其回答的格式。此 Skill 扮演了专业 Prompt 工程师的角色，帮助您为 AI 智能体、聊天机器人、代码助手或数据提取系统设计、编写和优化自定义指令。

## 为什么使用它？

- **适配特定模型的优化**：根据您所使用的 AI 模型自动调整 Prompt 结构（例如，为 Claude 使用 XML 标签，为 GPT 设定严格的格式参数，或为 Gemini 提供 temperature 指南）。
- **防止常见的 AI 错误**：引导您为复杂工作流构建运行手册（playbooks），并编写 AI 不易违背的规则。
- **科学的分层架构**：将 Prompt 组织为相互独立的区块（角色、上下文、指令、示例、安全边界），使指令清晰且无歧义。
- **应用 12 项通用原则**：基于 Anthropic、OpenAI 和 Google 官方提供的 Prompt 工程指南开发。
- **节省工程迭代时间**：在撰写前引导您进行快速访谈以收集完整需求，最大限度地减少反复修改 Prompt 的次数。

## 工作原理

1. **访谈收集需求**：AI 会询问您 10 个针对性问题，以收集关于目标模型、使用场景、角色设定、语气、严厉规则和期望示例的详细信息。
2. **分析复杂度**：评估任务规模（简单、中等或复杂）以规划 Prompt 的结构。
3. **结构化设计**：使用清晰的 XML 标签（如 `<role>`、`<instructions>`、`<guardrails>`）或标题来明确区分数据与指令。
4. **撰写与优化**：应用各种撰写原则（例如，解释规则背后的原因，使用肯定行为的陈述而非仅进行禁止）。
5. **最终评估**：检查一致性、异常情况，并提供测试 Prompt 供您进行实际运行测试。

## 如何触发

让 AI 执行如下任务：

```text
帮我为客户支持聊天机器人写一个系统 Prompt。
```

```text
为专业的 Python 代码审查 AI 智能体创建自定义指令。
```

```text
优化我现有的 Prompt，使其在 Claude 上运行得更好。
```

## 安装

### 1. 使用 CLI（推荐）

```bash
npx skills add tronghieu/agent-skills --skill system-prompt-creator
```

### 2. 手动安装（适合非技术用户）

1. **下载：** 转到此仓库的 `skills/` 文件夹下载 `system-prompt-creator.zip` 文件。
2. **解压和复制：** 解压 `system-prompt-creator.zip` 并将 `system-prompt-creator` 文件夹复制到以下目录之一：

**针对特定项目：**
将 `system-prompt-creator` 文件夹复制到项目根目录下的 `.agents/skills/` 或 `.claude/skills/`。

**全局安装（所有项目可用）：**
* **Mac / Linux：** `~/.agents/skills/` 或 `~/.claude/skills/`
* **Windows：** `%USERPROFILE%\.agents\skills\` 或 `%USERPROFILE%\.claude\skills\`（通常为 `C:\Users\<YourUsername>`）
